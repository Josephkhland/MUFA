#pragma once
#include "person.h"
#include "itemDataBase.h"
class society
{
	vector<person*> contacts;
	int level;
public:
	society();
	~society();

	int getNumberOfContacts();
	int generateRandomPerson(); //Incomplete
	person* generatePerson(string Name);
	void showContacts(bool longmode =false);
	void showContact(int index);
	void setLevel(int amount);
	person* getPerson(int index);
	person* getPerson(string Name);

	string generateItemName();
	

};

